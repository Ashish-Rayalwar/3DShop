import React from "react";
import Files from "../components/Files";

// import Login from "../components/Login";
// import SignUp from "../components/Signup";

const Home = () => {
  return (
    <div>
      <div style={{ marginTop: "90px" }}>
        <Files />
      </div>
    </div>
  );
};

export default Home;
