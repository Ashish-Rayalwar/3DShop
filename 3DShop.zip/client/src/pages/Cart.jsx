import React from "react";
// import Data from "../components/Data";

const Cart = () => {
  return <div></div>;
};

export default Cart;
